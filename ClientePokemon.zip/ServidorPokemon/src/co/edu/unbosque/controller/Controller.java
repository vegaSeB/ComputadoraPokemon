package co.edu.unbosque.controller;

import co.edu.unbosque.model.PokemonesDAO;
import co.edu.unbosque.servidor.Servidor;

public class Controller {
	
	public Controller() {
		PokemonesDAO pd = new PokemonesDAO();
		pd.agregarPokemonesDAO();
		Servidor server = new Servidor(5000);
		server.start();
		
	}

}
